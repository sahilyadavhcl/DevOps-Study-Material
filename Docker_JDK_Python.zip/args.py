def func1(*args):
    for i in args:
        print(i)
func1(2, 3, 44) 